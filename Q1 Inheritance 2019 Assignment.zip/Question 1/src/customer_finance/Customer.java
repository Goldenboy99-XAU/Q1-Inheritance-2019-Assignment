
package customer_finance;
//importing JOptionPane
import javax.swing.JOptionPane;

public class Customer 
{
  //declaration of variables 
    //Declaring customer detai
    public String customerName;  
    public String contactNumber;
    public String productPrice;
    public String numberOfMonths;
    public double totalPrice;
    public double price;
    int months;
    public  double repaymentAmount;
    public double discount;
    public double finalDiscount;
  
   //method for prompting a user for input(get & set)
    public void setCustomerName() 
    {
        customerName = JOptionPane.showInputDialog(null, "Please enter the customer name", "Customer Name", JOptionPane.QUESTION_MESSAGE);
    }
    
    public void setContactNum() 
    {
        contactNumber = JOptionPane.showInputDialog(null, "Please enter the customer contact number", "Customer Contact", JOptionPane.QUESTION_MESSAGE);
    }
    
    public void setproductPrice() 
    {
        productPrice = JOptionPane.showInputDialog(null, "Please enter the price of the product", "Product Price", JOptionPane.QUESTION_MESSAGE);
       price = Integer.parseInt(productPrice);
    }
    
    public void setnumberOfMonths() 
    {
        numberOfMonths = JOptionPane.showInputDialog(null, "Please enter the number of repayment months", "Number Of Months", JOptionPane.QUESTION_MESSAGE);
        months = Integer.parseInt(numberOfMonths);
    }
    
    public String getCustomerName() 
    {
        return customerName;
    }
    //
    public String getCustomerNum() 
    {
        return contactNumber;
    }
    //
    public String getproductPrice() 
    {
        return productPrice;
    }
    //
    public String getnumberOfMonths() 
    {
        return numberOfMonths;
    }
    //method to calculate repayment
    public void calculate_repayment() 
    {
      repaymentAmount = price / months;
        JOptionPane.showMessageDialog(null, "Customer Name: " + getCustomerName() + " \n"
                + "Customer Contact: " + getCustomerNum() + "\n "
                + "Product Price: R " + getproductPrice() + " \n"
                + "Repayment Months: " + getnumberOfMonths()+ " \n"
                + "Monthly Repayment: R " + repaymentAmount+"\n"
                +"Total Due: R"+getproductPrice());
     

    }

}

    
   
    


