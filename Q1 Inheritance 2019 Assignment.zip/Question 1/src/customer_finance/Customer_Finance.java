
package customer_finance;


//import javax.swing.JOptionPane;
public class Customer_Finance 
{

    
    public static void main(String[] args) 
    {
      
       Finance_Period obj =  new Finance_Period();
     
        obj.setCustomerName();
        obj.setContactNum();
        obj.setproductPrice();
        obj.setnumberOfMonths();
        obj.determine();
        
         
    }
    
}
