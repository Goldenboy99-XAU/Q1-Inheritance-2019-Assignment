
package customer_finance;

import javax.swing.JOptionPane;

//sub-class Financial_Period
public class Finance_Period extends Customer
{
   public void determine() 
    {
        if (months > 3) 
        {
            calculate_repayment();
        } 
        else  
        {
            super.calculate_repayment();
        }
    }

@Override
    public void calculate_repayment() 
    {   
        double discount = price/months;
        double discount1 = (discount * 0.25) + discount;
        double finalD  = discount1*months;
        JOptionPane.showMessageDialog(null,
                " Customer Name: "+getCustomerName()+ " \n"
                +" Customer Contact: "+getCustomerNum()+ "\n "
                +"Product Price: R"+getproductPrice()+ " \n"
                + " Repayment Months: "+getnumberOfMonths()+ " \n"
                + " Monthly Repayment: R"+discount1+"\n"
                + " Total Due : R"+finalD);

    }
}

